
<?php $__env->startSection('title'); ?>
    Dashbard || Experites
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-main'); ?>
<div class="card">
    <div class="card-header border-bottom">
    	<?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
			    <?php endif; ?>
			    <?php if(session('success')): ?>
			    <div class="alert alert-success">
			        <?php echo e(session('success')); ?>

			    </div>
					<?php endif; ?>
					 <?php if(session('error')): ?>
				    <div class="alert alert-danger">
				        <?php echo e(session('error')); ?>

				    </div>
					<?php endif; ?>
      <div class="card-title">
      	<form action="<?php echo e(isset($experties)?route('admin.experties.update',$experties->id):route('admin.experties.store')); ?>" method="post">
      			<?php echo csrf_field(); ?>
      			<?php if(isset($experties)): ?>
      			<?php echo method_field("PUT"); ?>
      			<?php endif; ?>
	      	<div class="row">
	      		<div class="col-6">
	      			<div >
					    <label for="experties" class="form-label">Experties</label>
					    <input type="test" class="form-control" id="experties" value="<?php echo e(isset($experties)?$experties->experties:''); ?>" name="experties">
					</div>
				</div>
	      		<div class="col-6 mt-4">
	      			<button type="submit" class="btn btn-primary"><?php echo e(isset($experties)?"Update":"Add"); ?></button>
	      		</div>
	      	</div>
      	</form>
      	
      </div>
      <div class="d-flex justify-content-between align-items-center row pb-2 gap-3 gap-md-0">
        <div class="col-md-4 user_role"></div>
        <div class="col-md-4 user_plan"></div>
        <div class="col-md-4 user_status"></div>
      </div>
    </div>
    <div class="card-datatable table-responsive">
      <table class="datatables table border-top">
        <thead>
          <tr>
            <th>Sr. No.</th>
            <th>Experties</th>
            <th>Actions</th>
          </tr>
        </thead>
        
      </table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
 <script>
        $(document).ready(function() {
            $('.datatables').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo route('admin.experties.index'); ?>',
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                    { data: 'experties', name: 'experties' },
                    {data: 'action', name: 'action',  orderable: true, searchable: true},

                    // Add more column definitions here
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\astrology_new\Theallsif-astro\resources\views/admin/experties/experties_index.blade.php ENDPATH**/ ?>