@extends('admin.app')
@section('title')
    Dashbard|{{Auth::guard('admin')->user()->name}}
@endsection

@section('content-main')
aldskjf
@endsection