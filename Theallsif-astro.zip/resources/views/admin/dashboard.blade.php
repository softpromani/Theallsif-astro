@extends('admin.app')
@section('content-main')
<h1>welcome astrologynew</h1>
@endsection